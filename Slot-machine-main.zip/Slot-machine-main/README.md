# Slot-machine
Slot machine created with Python. It's my first coding project.
